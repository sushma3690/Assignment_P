package com.putnam.studentms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;

import com.putnam.studentms.model.Student;

public interface StudentService {
	List<Student> getAllStudents();
	Page<Student> getAllStudentsPaginated(Integer pageNo, Integer pageSize);
    Optional<Student> getSingleStudent(Long userId);
    Student createStudent(Student student);
    void partiallyUpdateStudent(Student student);
    void updateStudent(Student student);
    void deleteStudent(Long student);
    Object getAllMarks();
}
