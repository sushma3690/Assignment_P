package com.putnam.studentms;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class GenerateData {

	public static void main(String[] args) throws IOException {
		 FileWriter myWriter = new FileWriter("SQLData.txt");
		 for(int i = 0; i < 3000000;i++) {
			 int leftLimit = 97; // letter 'a'
			    int rightLimit = 122; // letter 'z'
			    int targetStringLength = 5;
			    Random random = new Random();
			 
			    String generatedString = random.ints(leftLimit, rightLimit + 1)
			      .limit(targetStringLength)
			      .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
			      .toString();
			   // System.out.println(generatedString);
			 
			    myWriter.write("insert into student (name) values ('"+generatedString+"') \n");
		 }
		 myWriter.close(); 
	}
}
