package com.putnam.studentms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.putnam.studentms.model.Student;
import com.putnam.studentms.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

private static final Logger LOGGER = LoggerFactory.getLogger(StudentServiceImpl.class);
private final StudentRepository StudentRepository;

StudentServiceImpl(StudentRepository StudentRepository){
	this.StudentRepository = StudentRepository;
}

@Override
public List<Student> getAllStudents() {
    LOGGER.info("************");
    LOGGER.info("getting all Students");
    return StudentRepository.findAll();
    }

@Override
public Optional<Student> getSingleStudent(Long StudentId) {
	LOGGER.info("************");
    LOGGER.info("getting single Student");
    return StudentRepository.findById(StudentId);

}

@Override
public Student createStudent(Student student) {
	// TODO Auto-generated method stub
	Student StudentCreated = StudentRepository.save(student);
	return StudentCreated;
}

@Override
public void partiallyUpdateStudent(Student student) {
	// TODO Auto-generated method stub
	
}

@Override
public void updateStudent(Student student) {
	// TODO Auto-generated method stub
	
}

@Override
public void deleteStudent(Long StudentId) {
	// TODO Auto-generated method stub
	StudentRepository.deleteById(StudentId);
	
}

@Override
public Object getAllMarks() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public Page<Student> getAllStudentsPaginated(Integer pageNo, Integer pageSize) {
	// TODO Auto-generated method stub
    Pageable paging = PageRequest.of(pageNo, pageSize);

    Page<Student> pagedResult = StudentRepository.findAll(paging);
     
	/*
	 * if(pagedResult.hasContent()) { // return pagedResult.getContent(); } else {
	 * return new ArrayList<Student>(); }
	 */
    return pagedResult;

}
}
