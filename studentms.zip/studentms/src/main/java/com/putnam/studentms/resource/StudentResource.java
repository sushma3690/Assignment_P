package com.putnam.studentms.resource;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.putnam.studentms.model.AggregatorBean;
import com.putnam.studentms.model.Marks;
import com.putnam.studentms.model.Student;
import com.putnam.studentms.model.Subject;
import com.putnam.studentms.service.StudentService;

//import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
//@EnableSwagger2
//@RequestMapping("/api/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class StudentResource {

	private final StudentService studentService;

	public StudentResource(StudentService studentService) {
		this.studentService = studentService;
	}

	@GetMapping("/students")
	public ResponseEntity getAllStudents() {
		//System.out.println(StudentService.getAllStudents().get(0).getMarks().get(0).getMarks());
		Map<String, List<Student>> hm = new HashMap<>();
		hm.put("students", studentService.getAllStudents());
		Map<String, Map<String, List<Student>>> hm1 = new HashMap<>();
		hm1.put("_embedded", hm);
		return ResponseEntity.ok(hm1);

	}
	
	@GetMapping("/students-pagination")
	public ResponseEntity getAllStudentsPaginated(
            @RequestParam(defaultValue = "0") Integer pageNo, 
            @RequestParam(defaultValue = "10") Integer pageSize
          ) {
		//System.out.println(StudentService.getAllStudents().get(0).getMarks().get(0).getMarks());
		Map<String, Object> hm1 = new HashMap<>();
		Map<String, Object> hm = new HashMap<>();
		Page<Student> studentPage= studentService.getAllStudentsPaginated(pageNo, pageSize);

		hm.put("students", studentPage.getContent());
		/*
		 * hm.put("totalStudentCount", studentPage.getTotalElements());
		 * hm.put("totalPageCount", studentPage.getTotalPages()); hm.put("number",
		 * studentPage.getNumber()); hm.put("size", studentPage.getSize());
		 */
		hm1.put("_embedded", hm);


		Map<String, String> hm2 = new HashMap<>();
		hm2.put("size", String.valueOf(studentPage.getSize()));
		hm2.put("totalElements", String.valueOf(studentPage.getTotalElements()));
		hm2.put("totalPages", String.valueOf(studentPage.getTotalPages()));
		hm2.put("number", String.valueOf(studentPage.getNumber()));
		hm1.put("page", hm2);


		return ResponseEntity.ok(hm1);

	}

	@GetMapping("/students/{rollNumber}")
	public ResponseEntity getAllStudents(@PathVariable Long rollNumber) {
		Optional<Student> student = studentService.getSingleStudent(rollNumber);
		if(student.isPresent()) {
			Student s = student.get();
			List<Marks> marks = s.getMarks();
			Iterator itr = marks.iterator();
			List<String[]> markSub = new ArrayList<String[]>();
			while(itr.hasNext()) {
				String [] ms = new String[2];
				Marks m = (Marks) itr.next();
				ms[0]= String.valueOf(m.getMarks());
				ms[1]=m.getSubject().getName();
				markSub.add(ms);
			}
			AggregatorBean res = new AggregatorBean();
			res.setName(s.getName());
			res.setRollNumber(s.getRollNumber());
			res.setSubjects(markSub);
			//return ResponseEntity.ok(student.get());
			return ResponseEntity.ok(res);
		}
		return ResponseEntity.notFound().build();

	}

	@PostMapping(value ="/students", consumes = MediaType.APPLICATION_JSON_VALUE,
	        produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity createStudent(@RequestBody Student student) throws URISyntaxException {
		Student s = studentService.createStudent(student);
		return ResponseEntity.created(new URI(s.getRollNumber().toString())).build();

	}

	//delete, put, patch
	@DeleteMapping("/students")
	public ResponseEntity deleteStudent(@RequestBody Student student) throws URISyntaxException {
		try {
			studentService.deleteStudent(student.getRollNumber());
			return ResponseEntity.ok().build();

		}catch(Exception e) {
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).build();
		}

	}
	
	//put -> full update full body idempotent not cahcheable
	//patch - partial update, required params, not idempotnt, cacheable


}
