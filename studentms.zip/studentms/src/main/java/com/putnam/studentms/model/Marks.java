package com.putnam.studentms.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Marks {

	@EmbeddedId
	MarksKey id;

	//@JsonBackReference
	@ManyToOne
	@MapsId("rollNumber")
	@JoinColumn(name = "rollNumber")
	Student student;

	//@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
	@MapsId("id")
	@JoinColumn(name = "id")
	Subject subject;

	double marks;

	public MarksKey getId() {
		return id;
	}

	public void setId(MarksKey id) {
		this.id = id;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	

}
