package com.putnam.studentms.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.Id;

import java.util.List;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table
public class Student {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long rollNumber;

	private String name;

	//@JsonManagedReference
	@JsonIgnoreProperties({"student","subject"})
	@OneToMany(mappedBy = "student",cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	List<Marks> marks; // 2

	public Long getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(Long rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Marks> getMarks() {
		return marks;
	}

	public void setMarks(List<Marks> marks) {
		this.marks = marks;
	}
	
	/*
	 * // Constructors, Getters, Setter public void addMarks(Marks mark) {
	 * marks.add(mark); mark.setClass(this); }
	 * 
	 * public void removeMaks(Marks mark) { marks.remove(mark); mark.setClass(null);
	 * }
	 */
	
	



}
