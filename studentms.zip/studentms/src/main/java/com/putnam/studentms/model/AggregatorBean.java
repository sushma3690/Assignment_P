package com.putnam.studentms.model;

import java.util.List;

public class AggregatorBean {

	private Long rollNumber;

	private String name;


	List<String[]> subjects;

	public Long getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(Long rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public List<String[]> getSubjects() {
		return subjects;
	}

	public void setSubjects(List<String[]> subjects) {
		this.subjects = subjects;
	}




}
